package com.shoppingai.smartlet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartletApplicationTests {

	@Test
	void contextLoads() {
	}

}
