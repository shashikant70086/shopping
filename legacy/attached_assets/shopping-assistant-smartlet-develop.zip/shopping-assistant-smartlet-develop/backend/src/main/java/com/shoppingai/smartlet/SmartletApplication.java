package com.shoppingai.smartlet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartletApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartletApplication.class, args);
	}

}
