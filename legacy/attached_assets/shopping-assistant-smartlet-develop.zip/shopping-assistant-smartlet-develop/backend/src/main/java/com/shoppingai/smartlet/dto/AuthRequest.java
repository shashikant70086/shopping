package com.shoppingai.smartlet.dto;

public class AuthRequest {
    public String email;
    public String password;
}
